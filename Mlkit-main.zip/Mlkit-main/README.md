# Mlkit
This is Machine Learning Technology by Android application.
